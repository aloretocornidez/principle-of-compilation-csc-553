/* function prototypes */

int foo(void);

void bar(int x);

char fgh(char hgf[]);

void f(void)
{
}

void g(void)
{
  int x;
  x = 10;
  x = x+1;
}
