/* local declarations */

int foo1(void)
{
  int a, b, c;
  char d, e;
  int f[10], g, h[10], i;

  return 0;
}

int foo2(void)
{
  int a, b, c;
  char d, e;
  int f[10], g, h[10], i;
  
  return 0;
}

int foo3(void)
{
  int a, b, c;
  char d, e;
  int f[10], g, h[10], i;
  
  return 0;
}
