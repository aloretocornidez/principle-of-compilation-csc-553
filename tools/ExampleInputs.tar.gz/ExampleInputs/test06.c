/* function prototypes and definitions */

void hhh(void);

int foo(int x), bar(void);

char iii(char y);

int x, y, z;

int foo(int x)
{
  int y;
  
  return 0;

}

void ggg(int a);

int bar(void)
{
  return 1;
}

void ggg(int x)
{
  return;
}

void hhh(void)
{
  return;
}

char iii(char x)
{
  return 'a';
}
