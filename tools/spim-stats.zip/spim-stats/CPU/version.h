#define SPIM_VERSION "Version 9.1.22 of May 9, 2020"
