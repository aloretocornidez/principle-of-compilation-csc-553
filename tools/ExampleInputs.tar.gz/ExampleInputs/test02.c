/* global declarations */

int a, b, c;

char d, e;

int f[10], g, h[10], i;

